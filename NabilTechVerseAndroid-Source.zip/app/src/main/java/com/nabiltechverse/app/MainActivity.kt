package com.nabiltechverse.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import android.util.Xml
import java.net.URL

private const val FEED_URL = "https://nabiltechverse.blogspot.com/feeds/posts/default?alt=rss"
private val Gold = Color(0xFFD6A84F)
private data class Post(val title: String, val link: String, val date: String, val summary: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NtvApp() }
    }
}

@Composable
private fun NtvApp() {
    var dark by remember { mutableStateOf(true) }
    var query by remember { mutableStateOf("") }
    var posts by remember { mutableStateOf<List<Post>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val bg = if (dark) Color(0xFF101820) else Color(0xFFFFF9ED)
    val surface = if (dark) Color(0xFF1A2630) else Color.White
    val fg = if (dark) Color(0xFFF4F1E8) else Color(0xFF242424)

    LaunchedEffect(Unit) {
        try { posts = loadFeed(); error = if (posts.isEmpty()) "No posts found yet." else null }
        catch (e: Exception) { error = "Could not load posts. Check your internet connection."; }
        loading = false
    }

    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Gold, background = bg, surface = surface)
                  else lightColorScheme(primary = Gold, background = bg, surface = surface)) {
        Scaffold(containerColor = bg, topBar = {
            TopAppBar(
                title = { Column { Text("NabilTechVerse", fontWeight = FontWeight.Bold, color = Gold); Text("Explore • Learn • Secure", fontSize = 11.sp, color = fg.copy(alpha=.7f)) } },
                actions = { IconButton(onClick = { dark = !dark }) { Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, "Toggle theme", tint = Gold) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = bg)
            )
        }, bottomBar = {
            NavigationBar(containerColor = surface) {
                NavigationBarItem(selected = true, onClick = {}, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Default.Category, null) }, label = { Text("Categories") })
                NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Default.BookmarkBorder, null) }, label = { Text("Saved") })
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                Spacer(Modifier.height(12.dp))
                Text("Welcome to the world of technology", color = fg, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("Cybersecurity, tutorials and tech guides.", color = fg.copy(alpha=.7f), fontSize = 13.sp)
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search articles...") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true,
                    shape = RoundedCornerShape(14.dp))
                Spacer(Modifier.height(16.dp))
                Text("LATEST ARTICLES", color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                when {
                    loading -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Gold) }
                    error != null -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { Text(error!!, color = fg) }
                    else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(posts.filter { it.title.contains(query, true) || it.summary.contains(query, true) }) { post ->
                            Card(colors = CardDefaults.cardColors(containerColor = surface), shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth().clickable { /* Open article in browser in a future enhancement */ }) {
                                Column(Modifier.padding(16.dp)) {
                                    Text(post.title, color = fg, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    if (post.date.isNotBlank()) Text(post.date, color = Gold, fontSize = 11.sp)
                                    Spacer(Modifier.height(6.dp))
                                    Text(post.summary, color = fg.copy(alpha=.75f), fontSize = 13.sp, maxLines = 3)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private suspend fun loadFeed(): List<Post> = withContext(Dispatchers.IO) {
    val parser = Xml.newPullParser()
    URL(FEED_URL).openConnection().apply { connectTimeout = 12000; readTimeout = 12000 }.getInputStream().use { input ->
        parser.setInput(input, null)
        val result = mutableListOf<Post>()
        var event = parser.eventType
        var title = ""; var link = ""; var date = ""; var description = ""; var tag = ""
        while (event != XmlPullParser.END_DOCUMENT && result.size < 30) {
            when (event) {
                XmlPullParser.START_TAG -> tag = parser.name
                XmlPullParser.TEXT -> when (tag) {
                    "title" -> title += parser.text
                    "link" -> link += parser.text
                    "pubDate" -> date += parser.text
                    "description" -> description += parser.text
                }
                XmlPullParser.END_TAG -> if (parser.name == "item") {
                    result.add(Post(title.trim(), link.trim(), date.trim(), description.replace(Regex("<[^>]*>"), " ").trim()))
                    title = ""; link = ""; date = ""; description = ""
                }
            }
            event = parser.next()
        }
        result
    }
}
